return {
    jokers_enabled = true,
    suits_enabled = true,
    enhancements_enabled = true,
    editions_enabled = true,
    vouchers_enabled = true,
    tags_enabled = true,
  }
  