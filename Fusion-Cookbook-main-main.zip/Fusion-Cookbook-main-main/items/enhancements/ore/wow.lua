SMODS.Enhancement {
    key = "wow", 
    atlas = 'enhanc_fus',
    pos = {
        x = 2,
        y = 2
    }, 
    config = {extra = {}},
    loc_vars = function(self, info_queue, card)
        return {
            vars={}
        }
    end
}