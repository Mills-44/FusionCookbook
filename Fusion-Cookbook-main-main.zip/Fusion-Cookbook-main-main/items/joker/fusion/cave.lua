SMODS.Joker {
    key = 'cave',
    loc_txt = {
        name = 'Cave Joker',
        text = {"Creates a random",
                "{C:attention}Ore{} card",
                "when blind selected"}
    },
    config = {},
    rarity = 3,
    atlas = 'joker',
    in_pool = function(self, args) 
        return false
      end,
    pos = { x = 1, y = 0 },
    cost = 5,

    loc_vars = function(self, info_queue, card)
        return { vars = {} }
    end,

    calculate = function(self, card, context)
    if context.setting_blind and not card.getting_sliced then
        G.E_MANAGER:add_event(Event({
            func = function() 
                local enhancement_keys = {'m_fus_sapph', 'm_fus_cob', 'm_fus_ori', 'm_fus_ruby', 'm_fus_cinna', 'm_fus_red', 'm_steel', 'm_gold', 'm_stone'}  -- These are your actual keys
                local random_key = pseudorandom_element(enhancement_keys, pseudoseed('cave'))
                local front = pseudorandom_element(G.P_CARDS, pseudoseed('front'))
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                local card = Card(G.play.T.x + G.play.T.w/2, G.play.T.y, G.CARD_W, G.CARD_H, front, G.P_CENTERS[random_key], {playing_card = G.playing_card})
                card:start_materialize({G.C.SECONDARY_SET.Enhanced})
                G.play:emplace(card)
                table.insert(G.playing_cards, card)
                return true
            end}))
        card_eval_status_text(context.blueprint_card or self, 'extra', nil, nil, nil, {message = localize('k_plus_ore'), colour = G.C.SECONDARY_SET.Enhanced})

        G.E_MANAGER:add_event(Event({
            func = function() 
                G.deck.config.card_limit = G.deck.config.card_limit + 1
                return true
            end}))
            draw_card(G.play,G.deck, 90,'up', nil)  
        end
    end}