SMODS.Booster {
  object_type = "Booster",
    kind = "Snack",
    key = 'snack_pack_mega',
    group_key = 'k_mills_snack_pack',
    atlas = 'snack_pack_mega',
    pos = { 
        x = 0, 
        y = 0 
    },
    config = {
      extra = 6,
      choose = 2
    },
    weight = .55,
    cost = 8,
    discovered = true,
    draw_hand = true
  }
  