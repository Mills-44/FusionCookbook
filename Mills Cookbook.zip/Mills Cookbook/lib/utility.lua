if not SMODS.JokerPools then
    SMODS.JokerPools = {}
end

-- Function to register a Joker into a specific pool
function register_joker_to_pool(pool_name, joker)
    if not SMODS.JokerPools[pool_name] then
        SMODS.JokerPools[pool_name] = {}
    end
    table.insert(SMODS.JokerPools[pool_name], joker)
end

-- Function to get all Jokers from a specific pool
function get_jokers_from_pool(pool_name)
    return SMODS.JokerPools[pool_name] or {}
end

-- Function to get a random Joker from multiple pools combined
function get_random_joker_from_multiple_pools(pool_names)
    local combined_pool = {}

    for _, pool_name in ipairs(pool_names) do
        local pool = SMODS.JokerPools[pool_name]
        if pool then
            for _, joker in ipairs(pool) do
                table.insert(combined_pool, joker)
            end
        end
    end

    if #combined_pool > 0 then
        return combined_pool[math.random(#combined_pool)]
    else
        return nil
    end
end

